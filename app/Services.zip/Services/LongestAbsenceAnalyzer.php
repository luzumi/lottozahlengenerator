<?php

namespace App\Services;

use App\Models\LottoNumber;

class LongestAbsenceAnalyzer
{
    private array $numbers;

    public function __construct()
    {
        $this->numbers = range(1, 49);
    }

    /**
     * gibt die 6 Zahlen zurück, die am längsten nicht gezogen wurden
     *
     * @return array
     */
    public function getLongestAbsence(): array
    {
        $absenceNumbers = $this->getLastDrawnDates();
        asort($absenceNumbers);
        return array_keys(array_slice($absenceNumbers, 0, 6, true));
    }

    /**
     * gibt die letzten Ziehungsdaten für die Zahlen zurück
     *
     * @return array
     */
    private function getLastDrawnDates(): array
    {
        $absenceNumbers = [];
        $lastDrawnDates = $this->getLastDrawnForAllNumbers();

        foreach ($this->numbers as $number) {
            $absenceNumbers[$number] = $lastDrawnDates[$number] ?? '0000-00-00';
        }

        return $absenceNumbers;
    }

    /**
     * gibt das Datum der letzten Ziehung für die Zahl zurück
     *
     * @return array
     */
    private function getLastDrawnForAllNumbers(): array
    {
        $columns = ['number_one', 'number_two', 'number_three', 'number_four', 'number_five', 'number_six'];
        $lastDrawn = [];

        foreach ($columns as $column) {
            $drawnNumbers = LottoNumber::orderBy($column)
                ->join('draws', 'lotto_numbers.drawing_id', '=', 'draws.id')
                ->orderByRaw("STR_TO_DATE(CONCAT(draws.year, '-', REPLACE(draws.draw_date, '.', '-')), '%Y-%m-%d') desc")
                ->get()
                ->pluck($column, 'draw_date');

            foreach ($drawnNumbers as $number => $date) {
                if (!isset($lastDrawn[$number]) || $date > $lastDrawn[$number]) {
                    $lastDrawn[$number] = $date;
                }
            }
        }

        return $lastDrawn;
    }
}
